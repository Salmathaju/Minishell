#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include "minishell.h"

void child_handler(int signum)
{
    wait(NULL);
}

void fore_ground()
{
    if(head == NULL)
    {
        printf("SORRY NO JOBS ARE THERE\n");
        return;
    }

    int status;
    int pid = head->child_pid;

    if(kill(pid, SIGCONT) == -1)
    {
        perror("kill");
        return;
    }

    waitpid(pid, &status, WUNTRACED);

    if(WIFEXITED(status) || WIFSIGNALED(status))
    {
        delete_first();
    }
}

void back_ground()
{
    if(head == NULL)
    {
        printf("SORRY NO JOBS ARE PRESENT\n");
        return;
    }

    int pid = head->child_pid;

    signal(SIGCHLD, child_handler);

    if(kill(pid, SIGCONT) == -1)
    {
        perror("kill");
        return;
    }

    printf("[%d] %s &\n", pid, head->command);

    delete_first();
}