#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include"minishell.h"
#include<string.h>

char *command(char *input_string)
{
    int i=0;
    char *command=malloc(20);
    while(input_string[i]!=' ' && input_string[i]!='\0')
    {
        
        command[i]=input_string[i];
        i++;
    }
    command[i]='\0';
    //printf("COMMAND EXTRACTED = [%s]\n",command);
    return command;

}