#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include "minishell.h"
#include <string.h>
#include <stdlib.h>

void execute_external_command(char *input_string)
{
    char *cmd_with_options[20];
    int i = 0;
    int fd[2];

    if(strchr(input_string, '|') != NULL)
    {
        printf("PIPE FOUND\n");

        if(pipe(fd) == -1)
        {
            perror("pipe");
            return;
        }

        printf("PIPE CREATED\n");
    }
    else
    {
        char *token = strtok(input_string, " ");

        while(token != NULL)
        {
            cmd_with_options[i] = token;
            i++;

            token = strtok(NULL, " ");
        }

        cmd_with_options[i] = NULL;

        execvp(cmd_with_options[0], cmd_with_options);

        perror("execvp");
    }
}


void execute_internal_commands(char *input_string)
{
   
    if(strcmp(input_string, "exit") == 0)
    {
        exit(0);
    }

   
    else if(strcmp(input_string, "jobs") == 0)
    {
        print_jobs();
    }

   
    else if(strcmp(input_string, "fg") == 0)
    {
        fore_ground();
    }

   
    else if(strcmp(input_string, "bg") == 0)
    {
        back_ground();
    }

   
    else if(strcmp(input_string, "pwd") == 0)
    {
        char path[100];

        if(getcwd(path, sizeof(path)) != NULL)
        {
            printf("%s\n", path);
        }
        else
        {
            perror("getcwd");
        }
    }

    /* cd */
    else if(input_string[0] == 'c' &&input_string[1] == 'd')
    {
        char *path;
        if(input_string[2] == '\0')
        {
            path = getenv("HOME");

            if(path == NULL)
            {
                printf("HOME IS NOT SET\n");
                return;
            }
        }

        /* cd <directory> */
        else if(input_string[2] == ' ')
        {
            path = input_string + 3;

            if(path[0] == '\0')
            {
                path = getenv("HOME");

                if(path == NULL)
                {
                    printf("HOME IS NOT SET\n");
                    return;
                }
            }

            /* cd ~ */
            if(path[0] == '~' && path[1] == '\0')
            {
                path = getenv("HOME");

                if(path == NULL)
                {
                    printf("HOME IS NOT SET\n");
                    return;
                }
            }
        }

        else
        {
            printf("Invalid cd command\n");
            return;
        }

        if(chdir(path) == -1)
        {
            perror("cd");
        }
    }

    /* echo */
    else if(strncmp(input_string, "echo", 4) == 0)
    {
        if(strcmp(input_string, "echo") == 0)
        {
            printf("\n");
        }
        else if(strcmp(input_string, "echo $SHELL") == 0)
        {
            printf("%s\n", getenv("SHELL"));
        }
        else if(strcmp(input_string, "echo $?") == 0)
        {
            printf("0\n");
        }
        else
        {
            printf("%s\n", input_string + 5);
        }
    }
}