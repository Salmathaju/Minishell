#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

struct node
{
    int child_pid;
    char command[100];
    struct node *link;
};
 

#define BUILTIN		1
#define EXTERNAL	2
#define NO_COMMAND  3

extern struct node *head;
extern char *external_commands[152];
extern char *internal_commands[];

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"


void scan_input(char *prompt, char *input_string);
char *command(char *input_string);

void copy_change(char *prompt, char *input_string);

int check_command_type(char *command);
void echo(char *input_string, int status);
void execute_internal_commands(char *input_string);
void execute_external_command(char *input_string);
void signal_handler(int sig_num);
void extract_external_commands(char **external_commands);
void insert_first(int pid, char *command);
void delete_first(void);
void print_jobs(void);
void back_ground(void);
void fore_ground(void);

#endif