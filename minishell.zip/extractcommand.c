#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include"minishell.h"
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
void extract_external_commands(char **external_commands)
{
    int fd;
    char buffer[50];
    char ch;
    int i=0,j=0;
    fd=open("external_command.txt",O_RDONLY);
    if(fd==-1)
    {
        printf("File not opened\n");
        return;
    }
    while(read(fd, &ch, 1))
    {
        if(ch =='\n')
        {
            buffer[j]='\0';
            if(j>0 && buffer[j-1]=='\r')
            {
                buffer[j-1]='\0';
            }
        external_commands[i]=malloc(strlen(buffer)+1);
        strcpy(external_commands[i],buffer);
        i++;
        j=0;
        }
        else
        {
            buffer[j++]=ch;
        }
    }
    external_commands[i]=NULL;
    close(fd);
}