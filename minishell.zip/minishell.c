#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include "minishell.h"
#include<stdlib.h>
#include<signal.h>
#include<string.h>
char *external_commands[152];
char *internal_commands[]={"echo","cd","pwd","exit","jobs","fg","bg",NULL};
int pid;
struct node *head=NULL;
void scan_input(char *prompt, char *input_string)
{
    while (1)
    {
        printf("%s", prompt);

        memset(input_string, '\0', 100);

      scanf("%[^\n]", input_string);
       getchar();

        if (strstr(input_string,"PS1="))
        {
            if ((strrchr(input_string,'\t') != NULL) || (strrchr(input_string,' ') != NULL)||(strrchr(input_string,'$')==NULL))
            {
                printf("Invalid Command\n");
               
            }
            else{
            strcpy(prompt, input_string + 4);
            }
        }
      else
       {
        char *cmd=command(input_string);
        int type=check_command_type(cmd);
        if(type==EXTERNAL)
        {
            pid=fork();
            int status;
            if(pid>0)
            {
                waitpid(pid,&status,WUNTRACED);
                if(WIFSTOPPED(status))
                {
                    insert_first(pid,input_string);
                }
            }
            else if(pid==0)
            {
            signal(SIGINT,SIG_DFL);
            signal(SIGTSTP,SIG_DFL);
            execute_external_command(input_string);
            }
        }
        else if(type==BUILTIN)
        {
        execute_internal_commands(input_string);
        //printf("BULT IN PENDING\n");
        }
        else
        {
        printf("COMMAND NOT FOUND\n");
    }
    free(cmd);
    }
   
    }
}       

int main()
{
    signal(SIGINT,signal_handler);
    signal(SIGTSTP,signal_handler);
    char input_string[100];
    system("clear");
    char prompt[100]="minishell$";
    extract_external_commands(external_commands);
    scan_input(prompt ,input_string);
    return 0;
}