#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include"minishell.h"

int check_command_type(char *command)
{
    int i, j;

    i = 0;

    while(external_commands[i] != NULL)
    {
        j = 0;

        while(command[j] != '\0' &&
              external_commands[i][j] != '\0' &&
              command[j] == external_commands[i][j])
        {
            j++;
        }

        if(command[j] == '\0' &&
           external_commands[i][j] == '\0')
        {
            return EXTERNAL;
        }

        i++;
    }

    i = 0;

    while(internal_commands[i] != NULL)
    {
        j = 0;
      
        while(command[j] != '\0' &&internal_commands[i][j] != '\0' &&command[j] == internal_commands[i][j])
        {
            j++;
        }

        if(command[j] == '\0' &&
           internal_commands[i][j] == '\0')
        {
            return BUILTIN;
        }

        i++;
    }

    return NO_COMMAND;
}