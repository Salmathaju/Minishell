#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include "minishell.h"
#include<string.h>
#include<stdlib.h>
#include<signal.h>

/*void signal_handler(int sig_num)
{
    int pid;
    if(sig_num == SIGINT)
    {
        if(pid == 0)
        {
            printf("\nminishell$");
        }
    }

    if(sig_num == SIGTSTP)
    {
        if(pid == 0)
        {
            printf("\nminishell$");
        }
    }
}*/


void signal_handler(int sig_num)
{
    if(sig_num == SIGINT)
    {
        printf("\n");
    }

    if(sig_num == SIGTSTP)
    {
        printf("\n");
    }
}