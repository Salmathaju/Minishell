#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include"minishell.h"
#include<stdlib.h>
#include<string.h>

void insert_first(int pid,char *command)
{
    struct node *new;
    new=malloc(sizeof(struct node));
    new->child_pid=pid;
    strcpy(new->command,command);
    new->link=head;
    head=new;
}  

void print_jobs()
{
    struct node *temp=head;
    while(temp!=NULL)
    {
        printf("%d %s\n",temp->child_pid,temp->command);
        temp=temp->link;
    }
}

void delete_first()
{
    if (head == NULL)
    {
        return;
    }

    struct node *temp = head;

    head = head->link;

    free(temp);
}